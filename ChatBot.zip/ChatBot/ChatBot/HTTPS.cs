﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Collections.Specialized;
using System.IO;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Xml;
using System.Xml.Serialization;

static class HTTPS
{
    private static CookieContainer cookies = new CookieContainer();
    private static bool connected = false;

    private static bool OnValidationCallback(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors errors)
    {
        return true;
    }

    public static string HttpGet(string URI)
    {
        ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security
        .RemoteCertificateValidationCallback(OnValidationCallback);
        System.Net.HttpWebRequest req = (HttpWebRequest)System.Net.WebRequest.Create(URI);
        req.CookieContainer = cookies;
        System.Net.WebResponse resp = req.GetResponse();
        System.IO.StreamReader sr = new System.IO.StreamReader(resp.GetResponseStream());
        return sr.ReadToEnd().Trim();
    }



    private static string HttpPost(string URI, string Parameters)
    {
        ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(OnValidationCallback);
        System.Net.HttpWebRequest req = (HttpWebRequest)System.Net.WebRequest.Create(URI);
        req.CookieContainer = cookies;
        req.ContentType = "application/x-www-form-urlencoded";
        req.Method = "POST";
        byte[] bytes = System.Text.Encoding.ASCII.GetBytes(Parameters);
        req.ContentLength = bytes.Length;
        System.IO.Stream os = req.GetRequestStream();
        os.Write(bytes, 0, bytes.Length);
        os.Close();
        System.Net.WebResponse resp = req.GetResponse();
        if (resp == null) return null;
        System.IO.StreamReader sr = new System.IO.StreamReader(resp.GetResponseStream());
        return sr.ReadToEnd().Trim();
    }



    //public static List<string> GetWSSPortfolio(string user, string password)
    //{
    //    string no_stock = "<h4>You don&rsquo;t have any stock in your portfolio yet.</h4>";
    //    string accepted = string.Format("var wss_username = '{0}';", user);
    //    string portfolio = no_stock;
    //    List<string> symbols = new List<string>();
    //    object symb = null;
    //    object price = null;
    //    object profit = null;
    //    object[] request;
    //    if (connected == false)
    //    {
    //        string server_response = HTTPS.HttpPost("https://www.wallstreetsurvivor.com/login", string.Format("ReturnUrl=&LoginModel.UserName={0}&LoginModel.Password={1}&LoginModel.RememberMe=false", user, password));

    //        if (server_response.Contains(accepted))
    //        {
    //            connected = true;
    //            string positions = "";
    //            while (portfolio.Contains(no_stock))
    //            {
    //                portfolio = HTTPS.HttpGet("http://www.wallstreetsurvivor.com/play/portfolio/1");
    //                if (portfolio.Contains(no_stock))
    //                {
    //                    System.Threading.Thread.Sleep(5000);
    //                }

    //            }
    //            positions = portfolio.Substring(portfolio.IndexOf(@"{""PortfolioID"":"));
    //            positions = positions.Substring(0, positions.IndexOf(@"],""Last"":"));
    //            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
    //            request = (object[])jsSerializer.DeserializeObject("[" + positions + "]");

    //            foreach (object o in request)
    //            {
    //                Dictionary<string, object> pos = (Dictionary<string, object>)o;
    //                pos.TryGetValue("Symbol", out symb);
    //                pos.TryGetValue("AveragePricePaid", out price);
    //                pos.TryGetValue("ProfitLossPercentageDelayed", out profit);
    //                profit = profit + "%";
    //                symbols.Add(string.Format("{0}", symb));
    //                //symbols.Add(string.Format("{0} {1}", price, profit));
    //            }


    //        }


    //    }
    //    else MessageBox.Show("Connection Failed");
    //    return symbols;
    //}
}




//    public static List<string> GetGamePortfolio(string user, string password)
//    {
//        string accepted = "<message>Login successful</message>";
//        string accepted2 = string.Format("<username>{0}</username>", user);
//        string portfolio = string.Empty;
//        List<string> symbols = new List<string>();
//        if (connected == false)
//        {
//            string server_response = HTTPS.HttpPost("http://www.stockmarketgame.org/cgi-bin/hailogin", string.Format("ACCOUNTNO={0}&USER_PIN={1}&SECURITY_STRING=", user, password));

//            if (server_response.Contains(accepted) && server_response.Contains(accepted2))
//            {
//                MessageBox.Show("Connected");
//                string positions = "";
//                portfolio = HTTPS.HttpGet("http://www.stockmarketgame.org/cgi-bin/haipage/page.html?tpl=Administration/game/a_trad/cont_acctholdings&_=1474721631402");
//                if (portfolio.Contains("<ticker>"))
//                {
//                    positions = portfolio.Substring(portfolio.IndexOf(@"<transactions>"));
//                    positions = positions.Substring(0, positions.IndexOf(@"</response>"));
//                    XmlDocument doc = new XmlDocument();
//                    doc.InnerXml = positions;
//                    XmlNodeList nodelist = doc.SelectNodes("transactions/record");
//                    string ticker = string.Empty;
//                    string price = string.Empty;
//                    string gain = string.Empty;
//                    foreach (XmlNode record in nodelist) 
//                    {
//                        ticker = string.Empty;
//                        price = string.Empty;
//                        gain = string.Empty;
//                        foreach (XmlNode pos in record.ChildNodes)
//                        {
//                            if (pos.Name == "ticker") { ticker = pos.InnerText; };
//                            if (pos.Name == "netcost_pershare") { price = pos.InnerText; };
//                            if (pos.Name == "per_unrealized_gainslosses") { gain = pos.InnerText; };

//                        }
//                        symbols.Add(string.Format("{0},{1},{2}", ticker, price, gain));

//                    }

//                }


//            }
//            else MessageBox.Show("Connection Failed");

//        }
//        return symbols;

//    }
//}
